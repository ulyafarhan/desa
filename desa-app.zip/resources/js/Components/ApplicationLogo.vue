<template>
    <div class="h-16 w-16 object-cover overflow-hidden border-2 border-blue-600 rounded-full ">
        <img
            src="/images/logo-desa.png"
            alt="Logo Desa"
            class="w-full h-full object-contain transition duration-300 ease-in-out transform hover:scale-110"
        />
    </div>
</template>