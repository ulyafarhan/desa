<?php

namespace App\Filament\Resources\PanduanResource\Pages;

use App\Filament\Resources\PanduanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePanduan extends CreateRecord
{
    protected static string $resource = PanduanResource::class;
}
