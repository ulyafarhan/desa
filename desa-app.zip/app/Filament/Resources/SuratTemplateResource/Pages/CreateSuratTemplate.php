<?php

namespace App\Filament\Resources\SuratTemplateResource\Pages;

use App\Filament\Resources\SuratTemplateResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSuratTemplate extends CreateRecord
{
    protected static string $resource = SuratTemplateResource::class;
}
