<?php

namespace App\Filament\Resources\PejabatDesaResource\Pages;

use App\Filament\Resources\PejabatDesaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePejabatDesa extends CreateRecord
{
    protected static string $resource = PejabatDesaResource::class;
}
