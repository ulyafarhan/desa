<?php

namespace App\Filament\Resources\SuratRequestResource\Pages;

use App\Filament\Resources\SuratRequestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSuratRequest extends CreateRecord
{
    protected static string $resource = SuratRequestResource::class;
}
